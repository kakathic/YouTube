rm -fr "$(find /data/app -name *com.google.android.youtube*)"
rm -fr /data/data/com.google.android.youtube
